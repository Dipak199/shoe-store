package com.shoestore.online.shoe.store1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class manager {
	@Id
	String name;
	String address;
	String tagline;
	String gstno;
	String mobile;
	String password;
	String email;
	public manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public manager(String name, String address, String tagline, String gstno, String mobile, String password,
			String email) {
		super();
		this.name = name;
		this.address = address;
		this.tagline = tagline;
		this.gstno = gstno;
		this.mobile = mobile;
		this.password = password;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTagline() {
		return tagline;
	}
	public void setTagline(String tagline) {
		this.tagline = tagline;
	}
	public String getGstno() {
		return gstno;
	}
	public void setGstno(String gstno) {
		this.gstno = gstno;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "manager [name=" + name + ", address=" + address + ", tagline=" + tagline + ", gstno=" + gstno
				+ ", mobile=" + mobile + ", password=" + password + ", email=" + email + "]";
	}
	

}
