package com.shoestore.online.shoe.store1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	String name;
	String id;
	String address;
	String refperson;
	String phone;
	String gender;
	String role;
	String salary; 
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String name, String id, String address, String refperson, String phone, String gender, String role,
			String salary) {
		super();
		this.name = name;
		this.id = id;
		this.address = address;
		this.refperson = refperson;
		this.phone = phone;
		this.gender = gender;
		this.role = role;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRefperson() {
		return refperson;
	}
	public void setRefperson(String refperson) {
		this.refperson = refperson;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + ", address=" + address + ", refperson=" + refperson
				+ ", phone=" + phone + ", gender=" + gender + ", role=" + role + ", salary=" + salary + "]";
	}
	

}
