package com.shoestore.online.shoe.store1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class cart {
	@Id
	String name;
	String id;
	String quantity;
	public cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public cart(String name, String id, String quantity) {
		super();
		this.name = name;
		this.id = id;
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "cart [name=" + name + ", id=" + id + ", quantity=" + quantity + "]";
	}

}
