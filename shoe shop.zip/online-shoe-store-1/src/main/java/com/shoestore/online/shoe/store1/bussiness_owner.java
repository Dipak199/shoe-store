package com.shoestore.online.shoe.store1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class bussiness_owner {
	@Id
	String name;
	String address;
	String tagline;
	String gst;
	String mobile;
	String email;
	public bussiness_owner() {
		super();
		// TODO Auto-generated constructor stub
	}
	public bussiness_owner(String name, String address, String tagline, String gst, String mobile, String email) {
		super();
		this.name = name;
		this.address = address;
		this.tagline = tagline;
		this.gst = gst;
		this.mobile = mobile;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTagline() {
		return tagline;
	}
	public void setTagline(String tagline) {
		this.tagline = tagline;
	}
	public String getGst() {
		return gst;
	}
	public void setGst(String gst) {
		this.gst = gst;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "bussiness_owner [name=" + name + ", address=" + address + ", tagline=" + tagline + ", gst=" + gst
				+ ", mobile=" + mobile + ", email=" + email + "]";
	}
	

}
