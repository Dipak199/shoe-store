package com.shoestore.online.shoe.store1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class order {
	@Id
	String  id;
	String date;
	String store;
	String customer;
	String quantity;
	public order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public order(String id, String date, String store, String customer, String quantity) {
		super();
		this.id = id;
		this.date = date;
		this.store = store;
		this.customer = customer;
		this.quantity = quantity;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
		this.store = store;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "order [id=" + id + ", date=" + date + ", store=" + store + ", customer=" + customer + ", quantity="
				+ quantity + "]";
	}
	

}
