package com.shoestore.online.shoe.store1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoeStore1Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShoeStore1Application.class, args);
		System.out.println("now we start the online shoe stote project");
	}

}
