package com.shoestore.online.shoe.store1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class product {
	@Id
	String name;
	String price;
	String quanity;
	String brand;
	String unit;
	String size;
	public product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public product(String name, String price, String quanity, String brand, String unit, String size) {
		super();
		this.name = name;
		this.price = price;
		this.quanity = quanity;
		this.brand = brand;
		this.unit = unit;
		this.size = size;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQuanity() {
		return quanity;
	}
	public void setQuanity(String quanity) {
		this.quanity = quanity;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	@Override
	public String toString() {
		return "product [name=" + name + ", price=" + price + ", quanity=" + quanity + ", brand=" + brand + ", unit="
				+ unit + ", size=" + size + "]";
	}
	

}
